<?php
$r = 0;
if($_POST['bmi_btn']){


if($r = 0)
{
  heaader("location: login.php");
}}
 ?>
 <html>
 <body>
   <form action="temp.php">
   <button  type="submit" class="btn btn-info1" name="bmi_btn"><b>Compute BMI</b></button>
 </form>
 </body>
 </html>
